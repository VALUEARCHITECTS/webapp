# R2 Bucket Backup Metadata

This directory contains metadata about files stored in Cloudflare R2 bucket.

## Files

- file_list.json: Complete database records with attachment URLs
- file_urls.txt: List of all file URLs
- README.md: This file

## Note

This backup contains file URLs and metadata only.
The actual image files are stored in Cloudflare R2 bucket: webapp-receipts

## Cloudflare R2 Protection

Cloudflare R2 has built-in durability (99.999999999%).
Your files are automatically replicated across multiple data centers.

For additional protection:
1. Enable R2 versioning (Cloudflare Dashboard -> R2 -> Settings)
2. Use R2 lifecycle policies
